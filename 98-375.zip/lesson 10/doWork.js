onmessage = function(e) {
	var info = e.data;
	var result = "Message from the main page: '" + info + "'.";
	
	postMessage(result);
}