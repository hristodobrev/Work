window.onload = startDemo;

function startDemo() {
	canvas = document.getElementById('canv');
	ctx = canvas.getContext('2d');
	setInterval(loop, 33);
}

