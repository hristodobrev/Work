console.log("I'm working");
localStorage['username'] = "Pesho";
localStorage['user_id'] = 5;
console.log(localStorage);
localStorage.clear();
console.log(localStorage);

window.onload = function (){
	var canvas = document.getElementById("canvas");
	var context = canvas.getContext("2d");
	context.fillStyle = "rgb(100, 200, 255)";
	context.fillRect(20, 20, 50, 50);
	context.strokeStyle = "rgb(255, 100, 50)";
	context.strokeRect(80, 20, 50, 50);
};

changeAll();
function changeRed(value) {
	document.getElementById("redValue").innerHTML = value;
	changeAll();
}
function changeGreen(value) {
	document.getElementById("greenValue").innerHTML = value;
	changeAll();
}
function changeBlue(value) {
	document.getElementById("blueValue").innerHTML = value;
	changeAll();
}
function changeAll(){
	var r = document.getElementById("redValue").innerHTML;
	var g = document.getElementById("greenValue").innerHTML;
	var b = document.getElementById("blueValue").innerHTML;
	document.getElementById("color").style.backgroundColor = "rgb(" + r + ", " + g + ", " + b + ")";
}