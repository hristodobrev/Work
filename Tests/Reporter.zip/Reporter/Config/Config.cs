﻿namespace Reporter.Config
{
    public static class Config
    {
        public static string DBFolder = "/db";
    }
}
