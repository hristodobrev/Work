﻿using System;
namespace Reporter.Exceptions
{
    class RecordNotFoundException : Exception
    {
    }
}
