﻿namespace Reporter.IO
{
    public interface IReader
    {
        string Read();
    }
}
