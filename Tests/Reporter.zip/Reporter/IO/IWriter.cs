﻿namespace Reporter.IO
{
    public interface IWriter
    {
        void WriteLine(string line);
    }
}
