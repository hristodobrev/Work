﻿namespace Reporter.Models
{
    public interface IRecord<T>
    {
        int Id { get; set; }
    }
}
