﻿app.controller('myCtrl', function ($scope) {
    $scope.name = 'John Doe';
    $scope.text = 'post@web.com';

    $scope.secretWord = 'S3Cr37';
});