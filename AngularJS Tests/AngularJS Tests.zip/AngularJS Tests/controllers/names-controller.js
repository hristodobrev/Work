﻿app.controller('namesCtrl', function ($scope) {
    $scope.names = [
        { name: 'Jane', country: 'Norway' },
        { name: 'Hege', country: 'Sweden' },
        { name: 'Kia', country: 'Denmark' }
    ];
});