﻿app.controller('myCtrl', function ($scope) {
    $scope.names = ['Phil', 'Liya', 'Tobu'];
    $scope.color = 'red';
});